Web Confession v1.0.0 - giúp bạn xây dựng 1 hệ thống Confession (chia sẻ tâm tư ẩn danh). :D

[Hướng dẫn]
- Vào http://domain.com/install để config lại thôi :3
*Nếu database không tự động nạp thì các bạn vào server/lib/data/mysql/raw để lấy file database.sql (file sql thủ công) để import vào mysql nhé!

Admin Page: http://domain.com/admin

---------
-- Tác giả: Vy Nghĩa (Nghia is Gay)
-- Fanpage: https://www.facebook.com/NghiaisGay
---------

(c) 2017 Vy Nghia